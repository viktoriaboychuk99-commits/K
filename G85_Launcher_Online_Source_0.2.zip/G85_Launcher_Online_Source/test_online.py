# SPDX-License-Identifier: GPL-3.0-or-later
import json,os,runpy,shutil,tempfile,tomllib,unittest,zipfile
from pathlib import Path
from unittest import mock
import prepare

ROOT=Path(__file__).resolve().parent
class OnlineSourceTests(unittest.TestCase):
    def test_mod_metadata(self):
        with (ROOT/'world-bridge/src/main/resources/META-INF/mods.toml').open('rb') as f:
            doc=tomllib.load(f)
        self.assertEqual(doc['mods'][0]['modId'],'g85world')
        self.assertEqual(doc['mods'][0]['version'],'0.2.0')
        resource=json.loads((ROOT/'world-bridge/src/main/resources/pack.mcmeta').read_text())
        self.assertEqual(resource['pack']['pack_format'],15)
    def test_workflow_structure(self):
        workflow=(ROOT/'.github/workflows/build-apk.yml').read_text()
        self.assertIn('workflow_dispatch:',workflow)
        self.assertIn('permissions:\n  contents: read',workflow)
        self.assertIn('--bridge-jar world-bridge/build/libs/g85-world-bridge-0.2.0.jar',workflow)
        self.assertIn('if-no-files-found: error',workflow)
        self.assertIn('test_online.py',workflow)
    def test_prepare_online_profile(self):
        v={'id':'fixture-v','loaders':['forge'],'game_versions':['1.20.1'],'version_type':'release',
           'date_published':'2026-01-01','dependencies':[], 'files':[{
           'primary':True,'filename':'e4mc-fixture.jar','size':100,
           'url':'https://cdn.modrinth.com/data/fixture/e4mc-fixture.jar','hashes':{'sha512':'a'*128}}]}
        with tempfile.TemporaryDirectory() as td:
            r=Path(td)
            shutil.copyfile(ROOT/'G85_Military_Extended_Forge_1.20.1.mrpack',r/'G85_Military_Extended_Forge_1.20.1.mrpack')
            jar=r/'bridge-fixture.jar'
            # Fixture only; these are not runnable classes or a delivered mod.
            with zipfile.ZipFile(jar,'w') as z:
                z.writestr('META-INF/mods.toml','modId="g85world"')
                z.writestr('net/g85/world/G85WorldMod.class',b'fixture')
                z.writestr('net/g85/world/SharedWorldScreen.class',b'fixture')
            with mock.patch.object(prepare,'ROOT',r),mock.patch.object(prepare,'versions',return_value=[v]):
                entries,ids=prepare.prepare_pack(jar)
            index=json.loads(entries['modrinth.index.json'])
            self.assertEqual(index['dependencies'],{'minecraft':'1.20.1','forge':'47.4.10'})
            self.assertIn('overrides/mods/g85-world-bridge-0.2.0.jar',entries)
            self.assertTrue(any(f['path']=='mods/e4mc-fixture.jar' for f in index['files']))
            self.assertEqual(ids,['fixture-v'])
            self.assertIn('G85_Public',(ROOT/'world-bridge/src/main/java/net/g85/world/ClientHooks.java').read_text())
    def test_sdk_version_parser(self):
        before=os.getcwd()
        try:
            with tempfile.TemporaryDirectory() as td:
                os.chdir(td)
                p=Path('upstream/ZalithLauncher/build.gradle.kts');p.parent.mkdir(parents=True)
                p.write_text('compileSdk { version = release(37) { minorApiLevel = 2 } }\nndkVersion = "25.2.9519653"')
                with mock.patch('shutil.which',return_value='/fixture/sdkmanager'),mock.patch('subprocess.run') as run:
                    runpy.run_path(str(ROOT/'ci_install_sdk.py'),run_name='__main__')
                args=run.call_args.args[0]
                self.assertIn('platforms;android-37.2',args)
                self.assertIn('ndk;25.2.9519653',args)
        finally: os.chdir(before)
    def test_publication_is_explicit_and_limited(self):
        hooks=(ROOT/'world-bridge/src/main/java/net/g85/world/ClientHooks.java').read_text()
        screen=(ROOT/'world-bridge/src/main/java/net/g85/world/SharedWorldScreen.java').read_text()
        self.assertIn('if (!requested || attempted',hooks)
        self.assertIn('if (!WORLD_ID.equals(directory)) return;',hooks)
        self.assertIn('new ConfirmScreen',screen)
        self.assertIn('Files.exists(',screen)
        self.assertNotIn('deleteRecursively',screen)
        self.assertIn('new JoinMultiplayerScreen',screen)
        self.assertIn('ConnectScreen.startConnecting',screen)

if __name__=='__main__':unittest.main()
