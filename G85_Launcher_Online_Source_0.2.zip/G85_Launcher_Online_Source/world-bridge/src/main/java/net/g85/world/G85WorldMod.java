// SPDX-License-Identifier: GPL-3.0-or-later
package net.g85.world;
import net.minecraftforge.fml.common.Mod;
@Mod(G85WorldMod.ID)
public final class G85WorldMod {
    public static final String ID = "g85world";
    public G85WorldMod() { }
}
