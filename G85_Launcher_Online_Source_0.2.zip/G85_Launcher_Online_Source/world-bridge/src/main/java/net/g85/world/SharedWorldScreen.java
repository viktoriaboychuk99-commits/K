// SPDX-License-Identifier: GPL-3.0-or-later
package net.g85.world;

import java.security.SecureRandom;
import java.nio.file.Files;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.ConfirmScreen;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;

/** One local host save. Guests connect to that host, not to a new copy of the save. */
public final class SharedWorldScreen extends Screen {
    private final Screen parent;
    private EditBox address;
    private String previousAddress = "";
    private String error = "";
    public SharedWorldScreen(Screen parent) {
        super(Component.literal("Общий мир G85"));
        this.parent = parent;
    }
    @Override protected void init() {
        int w = Math.min(300, this.width - 32);
        int x = (this.width - w) / 2;
        addRenderableWidget(Button.builder(Component.literal("Общий мир — открыть на моём телефоне"), b -> confirmHosting())
                .bounds(x, 54, w, 24).build());
        address = new EditBox(this.font, x, 96, w, 20, Component.literal("Адрес-приглашение e4mc или IP:порт"));
        address.setMaxLength(253);
        address.setHint(Component.literal("Адрес e4mc или IP:порт"));
        address.setValue(previousAddress);
        address.setResponder(value -> previousAddress = value);
        addRenderableWidget(address);
        addRenderableWidget(Button.builder(Component.literal("Подключиться к миру друга"), b -> connect())
                .bounds(x, 122, w, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Миры в локальной сети"), b -> {
            ClientHooks.cancelHosting();
            this.minecraft.setScreen(new JoinMultiplayerScreen(this));
        }).bounds(x, 150, w, 22).build());
        addRenderableWidget(Button.builder(Component.literal("Назад"), b -> onClose())
                .bounds(x, 180, w, 20).build());
    }
    private void confirmHosting() {
        this.minecraft.setScreen(new ConfirmScreen(yes -> {
            if (yes) openHost(); else this.minecraft.setScreen(this);
        }, Component.literal("Открыть общий мир?"),
           Component.literal("Мир будет доступен по публичному адресу e4mc, пока вы в нём. Используется внешний туннель. Не отправляйте адрес посторонним. Мир хранится только на вашем телефоне.")));
    }
    private void openHost() {
        Minecraft mc = this.minecraft;
        try {
            ClientHooks.requestHosting();
            if (mc.getLevelSource().levelExists(ClientHooks.WORLD_ID)) {
                mc.createWorldOpenFlows().loadLevel(this, ClientHooks.WORLD_ID);
            } else {
                // Refuse to overwrite a partial or damaged save. Never delete or replace it.
                if (Files.exists(mc.getLevelSource().getBaseDir().resolve(ClientHooks.WORLD_ID))) {
                    throw new IllegalStateException("Папка мира уже существует, но сохранение не читается. Сначала сделайте резервную копию и проверьте level.dat.");
                }
                LevelSettings settings = new LevelSettings("Общий мир G85", GameType.SURVIVAL, false,
                        Difficulty.NORMAL, false, new GameRules(), WorldDataConfiguration.DEFAULT);
                mc.createWorldOpenFlows().createFreshLevel(ClientHooks.WORLD_ID, settings,
                        new WorldOptions(new SecureRandom().nextLong(), true, false),
                        WorldPresets::createNormalWorldDimensions);
            }
        } catch (Exception e) {
            ClientHooks.cancelHosting();
            com.mojang.logging.LogUtils.getLogger().error("G85 world open failed", e);
            error = "Ошибка открытия мира. См. latest.log";
            mc.setScreen(this);
        }
    }
    private void connect() {
        String value = address.getValue().trim();
        // Accept only an address, never a URL, command, filesystem path or invite payload.
        if (value.isEmpty() || value.chars().anyMatch(c -> Character.isWhitespace(c) || c == 47 || c == 92)) {
            error = "Введите адрес сервера, а не ссылку.";
            return;
        }
        ClientHooks.cancelHosting();
        ServerAddress parsed = ServerAddress.parseString(value);
        ConnectScreen.startConnecting(this, this.minecraft, parsed,
                new ServerData("Общий мир друга", value, false), false);
    }
    @Override public void onClose() {
        ClientHooks.cancelHosting();
        this.minecraft.setScreen(parent == null ? new TitleScreen() : parent);
    }
    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);
        g.drawCenteredString(this.font, "Общий мир · интернет и LAN", this.width / 2, 36, 0xBBBBBB);
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, "Хозяин закрыл мир — сессия завершена", this.width / 2, 210, 0xBBBBBB);
        if (!error.isEmpty()) g.drawCenteredString(this.font, error, this.width / 2, 224, 0xFF7777);
    }
}
