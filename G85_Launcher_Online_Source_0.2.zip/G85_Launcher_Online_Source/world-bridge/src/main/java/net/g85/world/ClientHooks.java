// SPDX-License-Identifier: GPL-3.0-or-later
package net.g85.world;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.HttpUtil;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = G85WorldMod.ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientHooks {
    public static final String WORLD_ID = "G85_Public";
    private static boolean requested;
    private static boolean attempted;
    private static IntegratedServer active;
    private static int waitTicks;
    private ClientHooks() { }

    static void requestHosting() {
        requested = true;
        attempted = false;
        waitTicks = 0;
    }
    static void cancelHosting() { requested = false; }

    @SubscribeEvent
    public static void opening(ScreenEvent.Opening event) {
        if (event.getNewScreen() instanceof SelectWorldScreen) {
            event.setNewScreen(new SharedWorldScreen(event.getCurrentScreen()));
        }
    }
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        IntegratedServer server = mc.getSingleplayerServer();
        if (server == null) {
            if (active != null) {
                requested = false; attempted = false; active = null; waitTicks = 0;
            }
            return;
        }
        active = server;
        if (!requested || attempted || mc.player == null || mc.level == null) return;
        // Never publish unrelated existing saves automatically.
        String directory = server.getWorldPath(LevelResource.ROOT)
                .toAbsolutePath().normalize().getFileName().toString();
        if (!WORLD_ID.equals(directory)) return;
        if (++waitTicks < 40) return;
        attempted = true;
        if (server.isPublished()) return;
        try {
            boolean opened = server.publishServer(GameType.SURVIVAL, false, HttpUtil.getAvailablePort());
            if (opened) {
                say(mc, "Локальный доступ открыт. Дождитесь публичного адреса от e4mc в чате и отправьте его другу. Без адреса e4mc доступ через интернет ещё не подтверждён.");
            } else {
                say(mc, "Не удалось открыть LAN. Закройте мир и повторите вход. Подробности: latest.log.");
            }
        } catch (Exception e) {
            say(mc, "Ошибка открытия мира: " + e.getClass().getSimpleName() + ". Закройте мир и повторите вход.");
        }
    }
    private static void say(Minecraft mc, String message) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(message), false);
    }
}
