// SPDX-License-Identifier: GPL-3.0-or-later
package com.movtery.zalithlauncher.g85

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.movtery.zalithlauncher.game.renderer.Renderers
import com.movtery.zalithlauncher.setting.AllSettings

/** Prototype home screen. The original engine remains inside the same APK. */
class G85HomeActivity : Activity() {
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = Color.rgb(25,25,25)
        window.navigationBarColor = Color.rgb(25,25,25)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(25,25,25)) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24),dp(24),dp(24),dp(32))
        }
        scroll.addView(box)
        fun label(text: String, size: Float, color: Int = Color.WHITE) {
            box.addView(TextView(this).apply {
                this.text = text; textSize = size; setTextColor(color)
                setPadding(0,dp(8),0,dp(12))
                if (size >= 24) setTypeface(typeface,Typeface.BOLD)
            })
        }
        fun button(title: String, action: () -> Unit) {
            box.addView(Button(this).apply {
                text = title; isAllCaps = false; textSize = 16f
                minHeight = dp(52); setOnClickListener { action() }
            },LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })
        }
        label("G85 Launcher",30f)
        label("Неофициальная модификация Zalith Launcher 2 · экспериментальная версия",14f,Color.LTGRAY)
        label("Minecraft 1.20.1 · Forge 47.4.10",18f)
        label("Целевые настройки: 3074 МБ / Zink. Не применены до проверки доступного рендерера.",16f,Color.LTGRAY)
        button("Установить встроенную сборку") { importPack() }
        button("Применить 3074 МБ + Zink") { applyDefaults() }
        button("Открыть встроенный движок") { openEngine() }
        button("Общий мир — инструкция") {
            AlertDialog.Builder(this).setTitle("Общий мир через интернет")
                .setMessage("После установки сборки запустите Minecraft.\n\nХозяин: Одиночная игра → Общий мир → подтвердить открытие. Один мир создаётся или загружается автоматически. e4mc должен выдать адрес в чате.\n\nДруг: Одиночная игра → введите адрес → Подключиться. Для одной сети есть кнопка локальных миров.\n\nПри закрытии мира сессия завершается. Используется внешняя служба туннелирования. Сборка и работа на телефоне ещё не проверены.")
                .setPositiveButton("Понятно",null).show()
        }
        label("Мир работает на телефоне хозяина, пока открыта игра. Нужен интернет. Тестировать только на резервной копии мира.",16f,Color.LTGRAY)
        setContentView(scroll)
    }
    private fun openEngine() {
        startActivity(Intent().setClassName(packageName,
            "com.movtery.zalithlauncher.ui.activities.SplashActivity"))
    }
    private fun importPack() {
        val uri = Uri.parse("content://$packageName.g85pack/G85.mrpack")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            component = ComponentName(packageName,"com.movtery.activity.ImportModpackActivity")
            setDataAndType(uri,"application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(intent) }.onFailure { error(it) }
    }
    private fun applyDefaults() {
        runCatching {
            // Do not invent a renderer ID. Resolve one of the actually installed renderers.
            val zink = Renderers.getRenderers().firstOrNull {
                it.getRendererName().contains("zink",ignoreCase = true)
            } ?: throw IllegalStateException("Zink не найден. Выполните настройку движка и установите рендерер, затем вернитесь сюда.")
            AllSettings.ramAllocation.save(3074)
            AllSettings.renderer.save(zink.getUniqueIdentifier())
            Toast.makeText(this,"Общие настройки сохранены: 3074 МБ / ${zink.getRendererName()}. Проверьте переопределения профиля.",Toast.LENGTH_LONG).show()
        }.onFailure { error(it) }
    }
    private fun error(t: Throwable) {
        AlertDialog.Builder(this).setTitle("Требуется настройка")
            .setMessage(t.message ?: t.javaClass.simpleName).setPositiveButton("ОК",null).show()
    }
}
