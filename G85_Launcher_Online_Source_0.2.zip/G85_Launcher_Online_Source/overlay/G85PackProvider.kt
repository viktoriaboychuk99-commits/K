// SPDX-License-Identifier: GPL-3.0-or-later
package com.movtery.zalithlauncher.g85

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/** Same-app read-only provider. No arbitrary filesystem paths or URL fetching. */
class G85PackProvider : ContentProvider() {
    override fun onCreate() = true
    private fun pack(uri: Uri): File {
        if (uri.path != "/G85.mrpack") throw FileNotFoundException("Unknown asset")
        val ctx = requireNotNull(context)
        val file = File(ctx.cacheDir,"g85-bundled.mrpack")
        synchronized(G85PackProvider::class.java) {
            // Always refresh after an APK upgrade. The asset is a small manifest archive.
            val temp = File(ctx.cacheDir,"g85-bundled.mrpack.tmp")
            ctx.assets.open("g85/G85.mrpack").use { src ->
                temp.outputStream().use { dst -> src.copyTo(dst) }
            }
            if (!temp.renameTo(file)) throw FileNotFoundException("Cannot refresh bundled pack")
        }
        return file
    }
    override fun getType(uri: Uri) = "application/octet-stream"
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        if (mode != "r") throw FileNotFoundException("Read only")
        return ParcelFileDescriptor.open(pack(uri),ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?,
                       selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val file = pack(uri)
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE)
        return MatrixCursor(cols).apply {
            addRow(cols.map { when(it) {
                OpenableColumns.DISPLAY_NAME -> "G85.mrpack"
                OpenableColumns.SIZE -> file.length()
                else -> null
            }}.toTypedArray())
        }
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException("Read only")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException("Read only")
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException("Read only")
}
