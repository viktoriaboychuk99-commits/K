# SPDX-License-Identifier: GPL-3.0-or-later
import importlib.util,json,tempfile,unittest,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
import prepare

class PreparationTests(unittest.TestCase):
    def test_safe_replacement(self):
        self.assertEqual(prepare.replace_once('abc','b','B'),'aBc')
        for text in ('none','xx'):
            with self.assertRaises(ValueError): prepare.replace_once(text,'x','y')
    def test_versions(self):
        v=lambda i,d,t='release':dict(id=i,date_published=d,version_type=t,loaders=['forge'],game_versions=['1.20.1'])
        self.assertEqual(prepare.choose([v('a','2026-01-01'),v('b','2026-02-01'),v('c','2026-03-01','beta')])['id'],'b')
        with self.assertRaises(ValueError): prepare.choose([])
    def test_mod_origin(self):
        v={'id':'test','loaders':['forge'],'game_versions':['1.20.1'],'files':[{
          'primary':True,'filename':'e4mc.jar','url':'https://cdn.modrinth.com/data/test/e4mc.jar',
          'hashes':{'sha512':'a'*128},'size':100}]}
        self.assertEqual(prepare.mod_entry(v)['path'],'mods/e4mc.jar')
        v['files'][0]['filename']='../bad.jar'
        with self.assertRaises(ValueError): prepare.mod_entry(v)
        v['files'][0]['filename']='e4mc.jar'
        v['files'][0]['url']='https://other.invalid/test.jar'
        with self.assertRaises(ValueError): prepare.mod_entry(v)
    def test_patch_plan(self):
        with tempfile.TemporaryDirectory() as td:
            r=Path(td)
            def put(n,s):
                p=r/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
            put('LICENSE','GPL fixture')
            put('ZalithLauncher/build.gradle.kts','applicationId = zalithPackageName\napplicationIdSuffix = ".v2"\nsigningConfig = signingConfigs.getByName("debugBuild")\n')
            put(str(prepare.BASE/'java/com/movtery/zalithlauncher/setting/AllSettings.kt'),'val ramAllocation = intSetting("ramAllocation", null, min = 256)')
            put('ZalithLauncher/gradle.properties','launcher_name=ZalithLauncher\nlauncher_app_name=Zalith Launcher\nlauncher_short_name=ZL2\nlauncher_version_name=2.7.2\n')
            original='''<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application>
<activity android:name=".ui.activities.SplashActivity"><intent-filter>
<action android:name="android.intent.action.MAIN" />
<category android:name="android.intent.category.LAUNCHER" />
</intent-filter></activity></application></manifest>'''
            mp=r/prepare.BASE/'AndroidManifest.xml';put(str(prepare.BASE/'AndroidManifest.xml'),original)
            out=prepare.plan_patch(r)
            self.assertEqual(mp.read_text(),original) # Planning is non-mutating.
            xml=out[mp]
            ET.fromstring(xml)
            self.assertEqual(xml.count('android.intent.category.LAUNCHER'),1)
            self.assertIn('${applicationId}.g85pack',xml)
            self.assertIn('3074',out[r/prepare.BASE/'java/com/movtery/zalithlauncher/setting/AllSettings.kt'])
    def test_original_pack_preserved(self):
        with zipfile.ZipFile(prepare.ROOT/'G85_Military_Extended_Forge_1.20.1.mrpack') as z:
            self.assertIsNone(z.testzip())
            index=json.loads(z.read('modrinth.index.json'))
            self.assertEqual(index['dependencies']['forge'],'47.4.10')
            self.assertTrue(all(f['path'].startswith('mods/') for f in index['files']))

if __name__=='__main__':unittest.main()
