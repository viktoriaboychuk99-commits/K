#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Install SDK components specified by checked-out upstream; fail explicitly on drift."""
from pathlib import Path
import re, shutil, subprocess
text=Path('upstream/ZalithLauncher/build.gradle.kts').read_text()
ndk=re.search(r'ndkVersion\s*=\s*"([0-9.]+)"',text)
api=re.search(r'version\s*=\s*release\((\d+)\)',text)
minor=re.search(r'minorApiLevel\s*=\s*(\d+)',text)
if not api: api=re.search(r'compileSdk\s*=\s*(\d+)',text)
if not api or not ndk: raise SystemExit('SDK config changed; review upstream before building')
platform=api.group(1)+(('.'+minor.group(1)) if minor else '')
manager=shutil.which('sdkmanager')
if not manager: raise SystemExit('sdkmanager is not available')
subprocess.run([manager,'--install','platform-tools','platforms;android-'+platform,'ndk;'+ndk.group(1)],check=True)
