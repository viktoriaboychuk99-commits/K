#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Prepare an Android launcher source fork. Requires network; does not claim to build an APK."""
import argparse, hashlib, json, re, shutil, subprocess, urllib.request, urllib.parse, zipfile
from pathlib import Path
from datetime import datetime, timezone
ROOT = Path(__file__).resolve().parent
UPSTREAM = 'https://github.com/ZalithLauncher/ZalithLauncher2.git'
BASE = Path('ZalithLauncher/src/main')

def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('Upstream changed; expected one occurrence: ' + old)
    return text.replace(old, new, 1)

def plan_patch(repo):
    gradle = repo / 'ZalithLauncher/build.gradle.kts'
    settings = repo / BASE / 'java/com/movtery/zalithlauncher/setting/AllSettings.kt'
    manifest = repo / BASE / 'AndroidManifest.xml'
    props = repo / 'ZalithLauncher/gradle.properties'
    for p in (gradle, settings, manifest, props, repo/'LICENSE'):
        if not p.is_file():
            raise ValueError('Required upstream file missing: ' + str(p))
    g = gradle.read_text(encoding='utf-8')
    g = replace_once(g, 'applicationId = zalithPackageName', 'applicationId = "net.g85.launcher"')
    g = replace_once(g, 'applicationIdSuffix = ".v2"', '// G85: separate application ID')
    g = replace_once(g, 'signingConfig = signingConfigs.getByName("debugBuild")',
                     'signingConfig = signingConfigs.getByName("debug")')
    s = settings.read_text(encoding='utf-8')
    s = replace_once(s, 'intSetting("ramAllocation", null, min = 256)',
                     'intSetting("ramAllocation", 3074, min = 256)')
    m = manifest.read_text(encoding='utf-8')
    activity = re.compile(r'(<activity\b[^>]*android:name="\.ui\.activities\.SplashActivity"[\s\S]*?</activity>)')
    match = activity.search(m)
    if not match: raise ValueError('Splash activity declaration changed')
    splash = match.group(1)
    main_filter = re.compile(r'<intent-filter>\s*<action android:name="android.intent.action.MAIN"\s*/>\s*<category android:name="android.intent.category.LAUNCHER"\s*/>\s*</intent-filter>')
    if len(main_filter.findall(splash)) != 1:
        raise ValueError('Launcher intent changed')
    m = m[:match.start()] + main_filter.sub('', splash) + m[match.end():]
    m = m.replace('${packageName}.document.provider', '${applicationId}.document.provider')
    m = m.replace('${packageName}.provider', '${applicationId}.provider')
    insertion = '''
        <activity android:name="com.movtery.zalithlauncher.g85.G85HomeActivity"
            android:exported="true" android:screenOrientation="unspecified">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        <provider android:name="com.movtery.zalithlauncher.g85.G85PackProvider"
            android:authorities="${applicationId}.g85pack"
            android:exported="false" android:grantUriPermissions="true" />
'''
    m = replace_once(m, '</application>', insertion + '\n    </application>')
    p = props.read_text(encoding='utf-8')
    for key, value in {'launcher_name':'G85Launcher', 'launcher_app_name':'G85 Launcher',
                       'launcher_short_name':'G85', 'launcher_version_name':'0.2.0-online-experimental'}.items():
        p, n = re.subn(r'^'+re.escape(key)+r'=.*$', key+'='+value, p, flags=re.M)
        if n != 1: raise ValueError('Missing/ambiguous property: '+key)
    return {gradle:g, settings:s, manifest:m, props:p}

def api(path):
    req = urllib.request.Request('https://api.modrinth.com/v2/'+path,
          headers={'User-Agent':'G85Launcher-SourcePrototype/0.1 (+https://github.com/ZalithLauncher/ZalithLauncher2)'})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.load(r)

def versions(project):
    query = urllib.parse.urlencode({'loaders':json.dumps(['forge']), 'game_versions':json.dumps(['1.20.1'])})
    return api('project/'+urllib.parse.quote(project, safe='')+'/version?'+query)

def choose(vs):
    candidates = [v for v in vs if 'forge' in v.get('loaders',[]) and '1.20.1' in v.get('game_versions',[])]
    if not candidates: raise ValueError('No Forge 1.20.1 version found')
    releases = [v for v in candidates if v.get('version_type') == 'release']
    return sorted(releases or candidates, key=lambda v:v['date_published'], reverse=True)[0]

def mod_entry(v):
    if 'forge' not in v.get('loaders',[]) or '1.20.1' not in v.get('game_versions',[]):
        raise ValueError('Incompatible dependency: '+v.get('id','?'))
    fs = v.get('files',[])
    primary = [f for f in fs if f.get('primary')]
    if len(primary) == 1: f = primary[0]
    elif len(fs) == 1: f = fs[0]
    else: raise ValueError('Ambiguous mod file: '+v['id'])
    name = f['filename']
    if Path(name).name != name or '/' in name or '\\' in name or not name.endswith('.jar'):
        raise ValueError('Unsafe mod filename')
    u = urllib.parse.urlparse(f['url'])
    if u.scheme != 'https' or u.hostname != 'cdn.modrinth.com':
        raise ValueError('Unexpected download origin')
    hashes = f['hashes']
    if not re.fullmatch('[0-9a-fA-F]{128}', hashes.get('sha512','')):
        raise ValueError('No valid SHA-512')
    if not isinstance(f.get('size'),int) or f['size'] <= 0: raise ValueError('Invalid size')
    return {'path':'mods/'+name, 'hashes':hashes, 'fileSize':f['size'],
            'downloads':[f['url']], 'env':{'client':'required','server':'unsupported'}}

def prepare_pack(bridge_jar):
    source = ROOT/'G85_Military_Extended_Forge_1.20.1.mrpack'
    with zipfile.ZipFile(source) as z:
        entries = {n:z.read(n) for n in z.namelist() if not n.endswith('/')}
    index = json.loads(entries['modrinth.index.json'])
    if index['dependencies'] != {'minecraft':'1.20.1','forge':'47.4.10'}:
        raise ValueError('Unexpected base pack dependencies')
    pending = [choose(versions('qANg5Jrr'))]
    seen = set()
    while pending:
        if len(seen) > 32: raise ValueError('Dependency expansion limit reached')
        v = pending.pop()
        if v['id'] in seen: continue
        seen.add(v['id'])
        entry = mod_entry(v)
        same = [e for e in index['files'] if e['path'] == entry['path']]
        if same and same[0]['hashes'] != entry['hashes']: raise ValueError('Conflicting mod file')
        if not same: index['files'].append(entry)
        for dep in v.get('dependencies',[]):
            if dep.get('dependency_type') != 'required': continue
            if dep.get('version_id'):
                pending.append(api('version/'+urllib.parse.quote(dep['version_id'], safe='')))
            elif dep.get('project_id'):
                pending.append(choose(versions(dep['project_id'])))
            else: raise ValueError('Unresolvable required dependency')
    index['name'] = 'G85 Launcher Online Prototype'
    index['versionId'] = '0.2.0-online-experimental'
    index['summary'] = 'Bundled launcher profile with e4mc; Android and gameplay not tested.'
    bridge_data = bridge_jar.read_bytes()
    with zipfile.ZipFile(bridge_jar) as bridge_zip:
        if bridge_zip.testzip() is not None:
            raise ValueError('Corrupt bridge JAR')
        for name in ('META-INF/mods.toml','net/g85/world/G85WorldMod.class','net/g85/world/SharedWorldScreen.class'):
            if name not in bridge_zip.namelist(): raise ValueError('Missing compiled bridge component: '+name)
        if 'modId="g85world"' not in bridge_zip.read('META-INF/mods.toml').decode():
            raise ValueError('Unexpected bridge mod ID')
    entries['overrides/mods/g85-world-bridge-0.2.0.jar'] = bridge_data
    entries['modrinth.index.json'] = json.dumps(index,ensure_ascii=False,indent=2).encode()
    entries['overrides/G85_LAUNCHER_ONLINE_RU.txt'] = (
        'Одиночная игра → Общий мир → подтвердить открытие. Дождитесь адреса e4mc в чате.\n'
        'Друзья с той же сборкой: Сетевая игра → По адресу.\n'
        'Мир работает на телефоне хозяина и недоступен после его закрытия.\n'
        '3074 МБ / Zink настраиваются в лаунчере, не через options.txt.\n'
        'Используется внешняя служба туннеля. Адрес не публикуйте без необходимости.\n'
        'Проверка работы на Android и совместимости модов не проводилась.\n'
    ).encode()
    return entries, sorted(seen)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ref', default='main', help='Branch, tag or pinned commit; recorded in generated sources')
    parser.add_argument('--bridge-jar', type=Path, required=True, help='Compiled reobfuscated world-bridge JAR')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_./-]+',args.ref) or args.ref.startswith('-'):
        raise SystemExit('Invalid ref')
    if not args.bridge_jar.is_file(): raise SystemExit('Build world-bridge first; compiled JAR not found')
    repo = ROOT/'upstream'
    if repo.exists():
        raise SystemExit('upstream already exists. Preserve your work; use a fresh directory. No files were overwritten.')
    subprocess.run(['git','clone','--recursive',UPSTREAM,str(repo)],check=True)
    subprocess.run(['git','-C',str(repo),'checkout',args.ref],check=True)
    subprocess.run(['git','-C',str(repo),'submodule','update','--init','--recursive'],check=True)
    changes = plan_patch(repo)
    entries, version_ids = prepare_pack(args.bridge_jar)  # Failure leaves cloned upstream unchanged.
    for path,text in changes.items(): path.write_text(text,encoding='utf-8')
    dest = repo/BASE/'java/com/movtery/zalithlauncher/g85'
    dest.mkdir(parents=True,exist_ok=True)
    for name in ('G85HomeActivity.kt','G85PackProvider.kt'):
        shutil.copyfile(ROOT/'overlay'/name,dest/name)
    asset = repo/BASE/'assets/g85/G85.mrpack'
    asset.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(asset,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in entries.items(): z.writestr(name,data)
    commit = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
    (repo/'UPSTREAM_COMMIT.txt').write_text(commit+'\n',encoding='utf-8')
    (repo/'G85_BUILD_PROVENANCE.json').write_text(json.dumps({
        'upstream':UPSTREAM,'commit':commit,'e4mc_and_dependency_version_ids':version_ids,
        'prepared_at':datetime.now(timezone.utc).isoformat(),
        'bridge_sha512':hashlib.sha512(args.bridge_jar.read_bytes()).hexdigest(),
        'android_build_tested':False,'minecraft_tested':False},indent=2),encoding='utf-8')
    shutil.copyfile(ROOT/'README_RU.md',repo/'G85_README_RU.md')
    print('Prepared SOURCE fork:',repo)
    print('No APK was built. Review changes, install the required SDK/NDK, then build in Android Studio.')

if __name__ == '__main__': main()
